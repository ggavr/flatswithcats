import 'dotenv/config';

export const cfg = {
  botToken: process.env.BOT_TOKEN ?? '',
  channelId: process.env.CHANNEL_ID ?? '',
  notion: {
    token: process.env.NOTION_TOKEN ?? '',
    dbUsers: process.env.NOTION_DB_USERS ?? '',
    dbListings: process.env.NOTION_DB_LISTINGS ?? '',
    dbModeration: process.env.NOTION_DB_MODERATION ?? ''
  }
};

if (!cfg.botToken) console.warn('[cfg] BOT_TOKEN is empty');
