export class AppError extends Error {
  constructor(message: string, public code = 'APP_ERROR') {
    super(message);
  }
}
export class ValidationError extends AppError {
  constructor(message: string) { super(message, 'VALIDATION'); }
}
export class Forbidden extends AppError {
  constructor(message = 'Forbidden') { super(message, 'FORBIDDEN'); }
}
export class NotFound extends AppError {
  constructor(message = 'Not found') { super(message, 'NOT_FOUND'); }
}
