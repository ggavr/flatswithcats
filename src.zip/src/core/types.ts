export type UserRole = 'user' | 'moderator' | 'admin';
export type UserStatus = 'pending' | 'approved' | 'blocked';

export type ListingStatus = 'draft' | 'published' | 'archived';

export interface User {
  tgId: number;
  name?: string;
  city?: string;
  role: UserRole;
  status: UserStatus;
}

export interface Listing {
  id?: string;
  ownerTgId: number;
  country: string;
  city: string;
  apartment: string;
  cat: string;
  cost: string;
  dates: string;
  isPublic: boolean;
  status: ListingStatus;
  channelMessageId?: number;
}
