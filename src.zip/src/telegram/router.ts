import { Scenes, Telegraf, session } from 'telegraf';
import { onboardingScene } from './scenes/onboarding.scene';
import { newListingScene } from './scenes/newListing.scene';
import { myListingsScene } from './scenes/myListings.scene';
import { browseScene } from './scenes/browse.scene';
import { moderationScene } from './scenes/moderation.scene';
import { registerCommands } from './commands';

export const buildRouter = (bot: Telegraf) => {
  const stage = new Scenes.Stage([onboardingScene, newListingScene, myListingsScene, browseScene, moderationScene]);
  bot.use(session());
  bot.use(stage.middleware());
  registerCommands(bot, stage);
};
