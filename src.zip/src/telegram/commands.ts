import { Telegraf, Scenes } from 'telegraf';

export const registerCommands = (bot: Telegraf, stage: Scenes.Stage) => {
  bot.start((ctx) => ctx.scene.enter('onboarding'));
  bot.command('new', (ctx) => ctx.scene.enter('newListing'));
  bot.command('my', (ctx) => ctx.scene.enter('myListings'));
  bot.command('browse', (ctx) => ctx.scene.enter('browse'));
  bot.command('mod', (ctx) => ctx.scene.enter('moderation'));
};
