import type { Context, MiddlewareFn } from 'telegraf';
import { userService } from '../services/user.service';

export const requireApproved: MiddlewareFn<Context> = async (ctx, next) => {
  const tgId = ctx.from?.id;
  if (!tgId) return;
  const u = await userService.getByTgId(tgId);
  if (u?.status !== 'approved') {
    await ctx.reply('Доступ только после одобрения модератором.');
    return;
  }
  return next();
};
