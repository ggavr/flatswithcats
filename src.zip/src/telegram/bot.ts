import { Telegraf } from 'telegraf';
import { cfg } from '../core/config';
import { buildRouter } from './router';

export const createBot = () => {
  const bot = new Telegraf(cfg.botToken);
  buildRouter(bot);
  bot.catch((err, ctx) => {
    console.error('Bot error', err);
    ctx.reply?.('Что-то пошло не так. Попробуйте ещё раз позже.');
  });
  return bot;
};
