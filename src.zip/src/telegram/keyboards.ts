import { Markup } from 'telegraf';

export const kb = {
  main: () => Markup.keyboard([
    ['📝 Новое', '📂 Мои'],
    ['🔎 Смотреть', '👤 Профиль']
  ]).resize(),
};
