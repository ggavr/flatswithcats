import { Scenes } from 'telegraf';
import { moderationService } from '../../services/moderation.service';

export const moderationScene = new Scenes.BaseScene<Scenes.SceneContext>('moderation');
moderationScene.enter(async (ctx) => {
  await ctx.reply('Отправьте tgId пользователя для одобрения (временно, для MVP).');
});
moderationScene.on('text', async (ctx) => {
  const tgId = Number(ctx.message.text.trim());
  if (!Number.isFinite(tgId)) return ctx.reply('Нужно число tgId');
  await moderationService.approveUser(tgId);
  return ctx.reply(`Пользователь ${tgId} одобрен`);
});
