import type { Context } from 'telegraf';
import { Scenes } from 'telegraf';
import { userService } from '../../services/user.service';
import { templates } from '../templates';

interface S extends Scenes.WizardSessionData {
  name?: string;
  city?: string;
}
type Ctx = Scenes.WizardContext<S>;

export const onboardingScene = new Scenes.WizardScene<Ctx>(
  'onboarding',
  async (ctx) => {
    await ctx.reply('Как вас зовут?');
    return ctx.wizard.next();
  },
  async (ctx) => {
    if ('text' in ctx.message!) (ctx.wizard.state as any).name = ctx.message!.text;
    await ctx.reply('Из какого вы города?');
    return ctx.wizard.next();
  },
  async (ctx) => {
    if ('text' in ctx.message!) (ctx.wizard.state as any).city = ctx.message!.text;
    const tgId = ctx.from!.id;
    const { name, city } = ctx.wizard.state as any;
    const u = await userService.register({ tgId, name, city });
    await ctx.reply(templates.userWelcome(u));
    return ctx.scene.leave();
  }
);
