import { Scenes } from 'telegraf';
import type { Listing } from '../../core/types';
import { listingService } from '../../services/listing.service';

type Ctx = Scenes.WizardContext<Scenes.WizardSessionData>;

export const newListingScene = new Scenes.WizardScene<Ctx>(
  'newListing',
  async (ctx) => { await ctx.reply('Страна?'); return ctx.wizard.next(); },
  async (ctx) => { (ctx.wizard.state as any).country = ('text' in ctx.message!) ? ctx.message!.text : ''; await ctx.reply('Город?'); return ctx.wizard.next(); },
  async (ctx) => { (ctx.wizard.state as any).city = ('text' in ctx.message!) ? ctx.message!.text : ''; await ctx.reply('Квартира (тип/описание)?'); return ctx.wizard.next(); },
  async (ctx) => { (ctx.wizard.state as any).apartment = ('text' in ctx.message!) ? ctx.message!.text : ''; await ctx.reply('Кот (порода/кол-во)?'); return ctx.wizard.next(); },
  async (ctx) => { (ctx.wizard.state as any).cat = ('text' in ctx.message!) ? ctx.message!.text : ''; await ctx.reply('Стоимость?'); return ctx.wizard.next(); },
  async (ctx) => { (ctx.wizard.state as any).cost = ('text' in ctx.message!) ? ctx.message!.text : ''; await ctx.reply('Даты?'); return ctx.wizard.next(); },
  async (ctx) => {
    (ctx.wizard.state as any).dates = ('text' in ctx.message!) ? ctx.message!.text : '';
    const ownerTgId = ctx.from!.id;
    const s = ctx.wizard.state as any;
    const dto: Omit<Listing, 'ownerTgId' | 'status'> = {
      apartment: s.apartment, country: s.country, city: s.city, cat: s.cat, cost: s.cost, dates: s.dates,
      isPublic: true
    };
    const id = await listingService.create(ownerTgId, dto);
    await ctx.reply(`Листинг создан: ${id}`);
    return ctx.scene.leave();
  }
);
