import { Scenes } from 'telegraf';
export const browseScene = new Scenes.BaseScene<Scenes.SceneContext>('browse');
browseScene.enter(async (ctx) => ctx.reply('Публичные листинги: фильтры добавим позже.'));
