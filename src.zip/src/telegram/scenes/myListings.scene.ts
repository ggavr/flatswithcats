import { Scenes } from 'telegraf';
export const myListingsScene = new Scenes.BaseScene<Scenes.SceneContext>('myListings');
myListingsScene.enter(async (ctx) => ctx.reply('Пока без списка — позже добавим listMine().'));
