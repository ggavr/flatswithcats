import type { Listing, User } from '../core/types';

export const templates = {
  userWelcome: (u: User) => `Привет! ${u.name ?? ''} (${u.city ?? 'город не указан'})\nВаш статус: ${u.status}`,
  listing: (l: Listing) =>
`*${l.apartment}* — ${l.city}, ${l.country}
Кот: ${l.cat}
Стоимость: ${l.cost}
Даты: ${l.dates}
Публичность: ${l.isPublic ? 'Да' : 'Нет'}`
};
