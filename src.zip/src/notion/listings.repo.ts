import { notion, DB } from './notionClient';
import type { Listing } from '../core/types';

const text = (v: string) => [{ type: 'text', text: { content: v.slice(0, 1900) } }];

export const listingsRepo = {
  async create(d: Listing) {
    const props: any = {
      tgId: { number: d.ownerTgId },
      apartment: { title: text(d.apartment) },
      country: { rich_text: text(d.country) },
      city: { rich_text: text(d.city) },
      cat: { rich_text: text(d.cat) },
      cost: { rich_text: text(d.cost) },
      dates: { rich_text: text(d.dates) },
      isPublic: { checkbox: d.isPublic },
      status: { rich_text: text(d.status) }
    };
    const page = await notion.pages.create({
      parent: { database_id: DB.listings },
      properties: props
    } as any);
    return (page as any).id as string;
  },

  async update(id: string, patch: Partial<Listing>) {
    const props: any = {};
    if (patch.apartment) props.apartment = { title: text(patch.apartment) };
    if (patch.country)   props.country   = { rich_text: text(patch.country) };
    if (patch.city)      props.city      = { rich_text: text(patch.city) };
    if (patch.cat)       props.cat       = { rich_text: text(patch.cat) };
    if (patch.cost)      props.cost      = { rich_text: text(patch.cost) };
    if (patch.dates)     props.dates     = { rich_text: text(patch.dates) };
    if (typeof patch.isPublic === 'boolean') props.isPublic = { checkbox: patch.isPublic };
    if (patch.status)    props.status    = { rich_text: text(patch.status) };
    if (patch.channelMessageId) props.channelMessageId = { number: patch.channelMessageId };

    await notion.pages.update({ page_id: id, properties: props });
  }
};
