import { notion, DB } from './notionClient';

export interface ModTicket { id?: string; tgId: number; reason?: string; }

const text = (v: string) => [{ type: 'text', text: { content: v.slice(0, 1900) } }];

export const moderationRepo = {
  async create(t: ModTicket) {
    const page = await notion.pages.create({
      parent: { database_id: DB.moderation },
      properties: {
        tgId: { number: t.tgId },
        reason: { rich_text: t.reason ? text(t.reason) : [] },
        status: { rich_text: text('pending') }
      }
    } as any);
    return (page as any).id as string;
  }
};
