import { Client } from '@notionhq/client';
import { cfg } from '../core/config';

export const notion = new Client({ auth: cfg.notion.token });
export const DB = {
  users: cfg.notion.dbUsers,
  listings: cfg.notion.dbListings,
  moderation: cfg.notion.dbModeration
};
