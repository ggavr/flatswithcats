import { notion, DB } from './notionClient';
import type { User } from '../core/types';

const text = (v: string) => [{ type: 'text', text: { content: v.slice(0, 1900) } }];

export const usersRepo = {
  async upsertByTgId(u: User) {
    const existing = await this.findByTgId(u.tgId);
    const props: any = {
      tgId: { number: u.tgId },
      name: { rich_text: u.name ? text(u.name) : [] },
      city: { rich_text: u.city ? text(u.city) : [] },
      role: { rich_text: text(u.role) },
      status: { rich_text: text(u.status) }
    };
    if (existing?.id) {
      await notion.pages.update({ page_id: existing.id, properties: props });
      return existing.id;
    }
    const page = await notion.pages.create({
      parent: { database_id: DB.users },
      properties: { ...props, title: { title: text(`user-${u.tgId}`) } }
    } as any);
    return (page as any).id as string;
  },

  async findByTgId(tgId: number): Promise<(User & { id: string }) | null> {
    const q: any = await (notion as any).databases.query({
      database_id: DB.users,
      filter: { property: 'tgId', number: { equals: tgId } }
    });
    const p = q.results?.[0];
    if (!p) return null;
    const props = (p as any).properties;
    return {
      id: (p as any).id,
      tgId: props.tgId?.number ?? tgId,
      name: props.name?.rich_text?.[0]?.plain_text,
      city: props.city?.rich_text?.[0]?.plain_text,
      role: props.role?.rich_text?.[0]?.plain_text ?? 'user',
      status: props.status?.rich_text?.[0]?.plain_text ?? 'pending'
    };
  }
};
