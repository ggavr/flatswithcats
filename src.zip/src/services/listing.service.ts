import type { Listing } from '../core/types';
import { listingsRepo } from '../notion/listings.repo';

export const listingService = {
  async create(ownerTgId: number, dto: Omit<Listing, 'ownerTgId' | 'status'>) {
    const id = await listingsRepo.create({ ...dto, ownerTgId, status: 'draft' });
    return id;
  },
  async publish(id: string) {
    await listingsRepo.update(id, { status: 'published' });
  },
  async archive(id: string) {
    await listingsRepo.update(id, { status: 'archived' });
  }
};
