import type { User } from '../core/types';
import { usersRepo } from '../notion/users.repo';

export const userService = {
  async register(base: Pick<User, 'tgId' | 'name' | 'city'>): Promise<User> {
    const u: User = { ...base, role: 'user', status: 'pending' };
    await usersRepo.upsertByTgId(u);
    return u;
  },
  async getByTgId(tgId: number) {
    return usersRepo.findByTgId(tgId);
  },
  async approve(tgId: number) {
    const u = await usersRepo.findByTgId(tgId);
    if (!u) return null;
    await usersRepo.upsertByTgId({ ...u, status: 'approved' });
    return { ...u, status: 'approved' as const };
  }
};
