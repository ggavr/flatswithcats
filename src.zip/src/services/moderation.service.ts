import { userService } from './user.service';
export const moderationService = {
  async approveUser(tgId: number) {
    return userService.approve(tgId);
  }
};
