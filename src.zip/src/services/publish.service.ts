import { Telegraf } from 'telegraf';
import { cfg } from '../core/config';
import { listingsRepo } from '../notion/listings.repo';

export const publishService = {
  async publish(bot: Telegraf, listingId: string, text: string) {
    const res = await bot.telegram.sendMessage(cfg.channelId, text, { parse_mode: 'Markdown' });
    await listingsRepo.update(listingId, { channelMessageId: res.message_id, status: 'published' });
    return res.message_id;
  },
  async update(bot: Telegraf, msgId: number, text: string) {
    await bot.telegram.editMessageText(cfg.channelId, msgId, undefined, text, { parse_mode: 'Markdown' });
  },
  async unpublish(bot: Telegraf, msgId: number) {
    await bot.telegram.deleteMessage(cfg.channelId, msgId);
  }
};
